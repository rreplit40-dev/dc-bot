<?php

namespace Pterodactyl\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;

class RegisterVerificationCode extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(public string $code, public string $firstName)
    {
    }

    public function via(): array
    {
        return ['mail'];
    }

    public function toMail(): MailMessage
    {
        return (new MailMessage())
            ->subject('Verify your ' . config('app.name') . ' account')
            ->view('emails.verification-code', [
                'greeting' => 'Hello ' . $this->firstName . ',',
                'introLines' => [
                    'Use the verification code below to finish creating your account on ' . config('app.name') . '.',
                ],
                'outroLines' => [
                    'This code will expire in 10 minutes. If you did not request this, you can safely ignore this email.',
                ],
                'code' => $this->code,
            ]);
    }
}
