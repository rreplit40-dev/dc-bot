<?php

namespace Pterodactyl\Notifications;

use Pterodactyl\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;

class LoginIpVerificationCode extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(public User $user, public string $code, public string $ipAddress)
    {
    }

    public function via(): array
    {
        return ['mail'];
    }

    public function toMail(): MailMessage
    {
        return (new MailMessage())
            ->subject('New login detected on ' . config('app.name'))
            ->view('emails.verification-code', [
                'greeting' => 'Hello ' . ($this->user->name_first ?: $this->user->username) . ',',
                'introLines' => [
                    'We noticed a login attempt to your account from a device or location we do not recognize.',
                    'IP Address: ' . $this->ipAddress,
                ],
                'outroLines' => [
                    'Enter this code to complete your login. This code will expire in 10 minutes.',
                    'If this was not you, we recommend changing your password immediately.',
                ],
                'code' => $this->code,
            ]);
    }
}
