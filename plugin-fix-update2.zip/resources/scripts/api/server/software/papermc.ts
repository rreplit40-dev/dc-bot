// Client for PaperMC's "Fill" API v3 (https://docs.papermc.io/misc/downloads-service/).
// The old api.papermc.io/v2 endpoint stopped receiving new builds on Dec 31,
// 2025 and was fully sunset on Jul 1, 2026 (now returns HTTP 410). Fill v3
// replaces it. Covers Paper, Velocity, Waterfall and Folia — same API, just a
// different "project" key.

const FILL_API = 'https://fill.papermc.io/v3';

export type PaperProject = 'paper' | 'velocity' | 'waterfall' | 'folia';

interface ProjectVersionsResponse {
    // Versions grouped by release line, e.g. { "1.21": ["1.21", "1.21.1", ...] }
    versions: Record<string, string[]>;
}

interface BuildDownload {
    name: string;
    url: string;
    size: number;
}

export interface PaperBuild {
    id: number;
    channel: 'ALPHA' | 'BETA' | 'STABLE' | 'RECOMMENDED';
    downloads: Record<string, BuildDownload>;
}

// Compares two Minecraft-style version strings ("1.21.10" vs "1.21.2"),
// newest first — a plain string sort gets this wrong (1.21.10 < 1.21.2).
function compareVersionsDesc(a: string, b: string): number {
    const pa = a.split('.').map((n) => parseInt(n, 10) || 0);
    const pb = b.split('.').map((n) => parseInt(n, 10) || 0);

    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
        const diff = (pb[i] ?? 0) - (pa[i] ?? 0);
        if (diff !== 0) return diff;
    }

    return 0;
}

export async function getGameVersions(project: PaperProject): Promise<string[]> {
    const response = await fetch(`${FILL_API}/projects/${project}`);
    if (!response.ok) {
        throw new Error(`Failed to load ${project} versions (status ${response.status})`);
    }

    const data: ProjectVersionsResponse = await response.json();

    const all = Object.values(data.versions).flat();
    return all.sort(compareVersionsDesc);
}

export async function getBuilds(project: PaperProject, version: string): Promise<PaperBuild[]> {
    const response = await fetch(`${FILL_API}/projects/${project}/versions/${version}/builds`);
    if (!response.ok) {
        throw new Error(`Failed to load builds for ${project} ${version} (status ${response.status})`);
    }

    const builds: PaperBuild[] = await response.json();
    // Newest first.
    return [...builds].sort((a, b) => b.id - a.id);
}

export function buildDownload(build: PaperBuild): { url: string; filename: string } | null {
    const download = build.downloads['server:default'] ?? Object.values(build.downloads)[0];
    if (!download) return null;

    return { url: download.url, filename: download.name };
}

export async function getLatestBuildDownload(
    project: PaperProject,
    version: string
): Promise<{ url: string; filename: string; build: number }> {
    const builds = await getBuilds(project, version);
    if (!builds.length) {
        throw new Error(`No builds published for ${project} ${version}.`);
    }

    // Prefer the newest STABLE/RECOMMENDED build over an ALPHA/BETA one, but
    // fall back to whatever's newest.
    const preferred = builds.find((b) => b.channel === 'STABLE' || b.channel === 'RECOMMENDED') ?? builds[0];
    const download = buildDownload(preferred);

    if (!download) {
        throw new Error(`No downloadable jar found for ${project} ${version} build ${preferred.id}.`);
    }

    return { ...download, build: preferred.id };
}
