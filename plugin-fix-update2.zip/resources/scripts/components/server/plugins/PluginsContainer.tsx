import React, { useEffect, useState } from 'react';
import debounce from 'debounce';
import tw from 'twin.macro';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faDownload, faCheckCircle, faSearch } from '@fortawesome/free-solid-svg-icons';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import FlashMessageRender from '@/components/FlashMessageRender';
import Input from '@/components/elements/Input';
import Button from '@/components/elements/Button';
import GreyRowBox from '@/components/elements/GreyRowBox';
import Spinner from '@/components/elements/Spinner';
import Modal from '@/components/elements/Modal';
import useFlash from '@/plugins/useFlash';
import { ServerContext } from '@/state/server';
import pullFile from '@/api/server/files/pullFile';
import {
    ModrinthSearchHit,
    ModrinthVersion,
    PLUGIN_LOADERS,
    PluginLoader,
    getProjectVersions,
    searchPlugins,
} from '@/api/server/plugins/modrinth';

const PLUGINS_DIRECTORY = '/plugins';

// Which loader we default to search under. Server admins running Paper are
// by far the most common case, so that's the sane default.
const DEFAULT_LOADER: PluginLoader = 'paper';

type InstallState = 'idle' | 'installing' | 'installed' | 'error';

// The modal that lists every build of a single plugin so the user can pick
// exactly which one to install, instead of always getting the newest.
const VersionPickerModal = ({
    hit,
    loader,
    uuid,
    onDismissed,
    onInstalled,
}: {
    hit: ModrinthSearchHit;
    loader: PluginLoader;
    uuid: string;
    onDismissed: () => void;
    onInstalled: () => void;
}) => {
    const { addError, clearFlashes } = useFlash();
    const [loading, setLoading] = useState(true);
    const [versions, setVersions] = useState<ModrinthVersion[]>([]);
    const [installingId, setInstallingId] = useState<string | null>(null);

    useEffect(() => {
        clearFlashes('plugins:versions');
        getProjectVersions(hit.project_id, loader)
            .then(setVersions)
            .catch((error) => {
                console.error(error);
                addError({ key: 'plugins:versions', message: 'Could not load versions for this plugin.' });
            })
            .then(() => setLoading(false));
    }, [hit.project_id, loader]);

    const installVersion = (version: ModrinthVersion) => {
        const file = version.files.find((f) => f.primary) ?? version.files[0];
        if (!file) {
            addError({ key: 'plugins:versions', message: 'That version has no downloadable file.' });
            return;
        }

        setInstallingId(version.id);
        clearFlashes('plugins:versions');

        pullFile(uuid, { url: file.url, directory: PLUGINS_DIRECTORY, filename: file.filename })
            .then(() => onInstalled())
            .catch((error) => {
                console.error(error);
                setInstallingId(null);
                addError({ key: 'plugins:versions', message: 'Installation failed for that version.' });
            });
    };

    return (
        <Modal visible onDismissed={onDismissed} top={false}>
            <h2 css={tw`text-2xl mb-2`}>{hit.title}</h2>
            <p css={tw`text-sm text-neutral-400 mb-4`}>
                Pick a build to install for <span css={tw`text-neutral-200`}>{loader}</span>. It'll be downloaded
                straight into <code css={tw`text-neutral-300`}>/plugins</code>.
            </p>

            <FlashMessageRender byKey={'plugins:versions'} css={tw`mb-4`} />

            <div css={tw`max-h-96 overflow-y-auto pr-1`}>
                {loading ? (
                    <Spinner size={'large'} centered />
                ) : versions.length === 0 ? (
                    <p css={tw`text-sm text-neutral-400 text-center py-4`}>
                        No builds of this plugin support {loader}.
                    </p>
                ) : (
                    versions.map((version, index) => (
                        <GreyRowBox key={version.id} css={index > 0 ? tw`mt-2` : undefined}>
                            <div css={tw`flex-1 min-w-0`}>
                                <p css={tw`text-sm font-medium truncate`}>{version.version_number}</p>
                                <p css={tw`text-xs text-neutral-400 truncate`}>
                                    MC {version.game_versions.slice(0, 4).join(', ')}
                                    {version.game_versions.length > 4 ? '…' : ''}
                                </p>
                            </div>
                            <Button
                                size={'small'}
                                color={'primary'}
                                disabled={installingId !== null}
                                onClick={() => installVersion(version)}
                                css={tw`ml-4 flex-shrink-0`}
                            >
                                {installingId === version.id ? <Spinner size={'small'} /> : 'Install'}
                            </Button>
                        </GreyRowBox>
                    ))
                )}
            </div>
        </Modal>
    );
};

export default () => {
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const { addError, clearFlashes } = useFlash();

    const [loader, setLoader] = useState<PluginLoader>(DEFAULT_LOADER);
    const [query, setQuery] = useState('');
    const [loading, setLoading] = useState(false);
    const [results, setResults] = useState<ModrinthSearchHit[]>([]);
    const [installState, setInstallState] = useState<Record<string, InstallState>>({});
    const [activeHit, setActiveHit] = useState<ModrinthSearchHit | null>(null);

    const runSearch = debounce((value: string, forLoader: PluginLoader) => {
        setLoading(true);
        clearFlashes('plugins');

        searchPlugins(value, forLoader)
            .then((response) => setResults(response.hits))
            .catch((error) => {
                console.error(error);
                addError({ key: 'plugins', message: 'Could not reach Modrinth — try again in a moment.' });
            })
            .then(() => setLoading(false));
    }, 350);

    useEffect(() => {
        runSearch(query, loader);
        return () => runSearch.clear();
    }, [query, loader]);

    return (
        <ServerContentBlock title={'Plugins'}>
            <FlashMessageRender byKey={'plugins'} css={tw`mb-4`} />

            {activeHit && (
                <VersionPickerModal
                    hit={activeHit}
                    loader={loader}
                    uuid={uuid}
                    onDismissed={() => setActiveHit(null)}
                    onInstalled={() => {
                        setInstallState((prev) => ({ ...prev, [activeHit.project_id]: 'installed' }));
                        setActiveHit(null);
                    }}
                />
            )}

            <div css={tw`flex flex-col sm:flex-row gap-4 mb-4`}>
                <div css={tw`flex-1 relative flex items-center`}>
                    <FontAwesomeIcon
                        icon={faSearch}
                        css={tw`absolute left-4 text-neutral-400 text-sm pointer-events-none`}
                    />
                    <Input
                        css={tw`pl-11`}
                        placeholder={'Search plugins (e.g. EssentialsX, LuckPerms, Vault)'}
                        value={query}
                        onChange={(e) => setQuery(e.currentTarget.value)}
                    />
                </div>
                <select
                    css={tw`bg-neutral-600 border-2 border-neutral-500 rounded text-sm text-neutral-200 p-3`}
                    value={loader}
                    onChange={(e) => setLoader(e.currentTarget.value as PluginLoader)}
                >
                    {PLUGIN_LOADERS.map((l) => (
                        <option key={l} value={l}>
                            {l[0].toUpperCase() + l.slice(1)}
                        </option>
                    ))}
                </select>
            </div>

            <p css={tw`text-xs text-neutral-400 mb-4`}>
                Installing a plugin downloads its jar directly onto this server into{' '}
                <code css={tw`text-neutral-300`}>/plugins</code>. Restart the server for it to load.
            </p>

            {loading ? (
                <Spinner size={'large'} centered />
            ) : results.length === 0 ? (
                <p css={tw`text-center text-sm text-neutral-300`}>
                    {query ? 'No plugins found for that search.' : 'Start typing to search Modrinth for plugins.'}
                </p>
            ) : (
                results.map((hit, index) => {
                    const state = installState[hit.project_id] ?? 'idle';

                    return (
                        <GreyRowBox key={hit.project_id} css={index > 0 ? tw`mt-2` : undefined}>
                            {hit.icon_url ? (
                                <img src={hit.icon_url} css={tw`w-10 h-10 rounded mr-4`} alt={hit.title} />
                            ) : (
                                <div css={tw`w-10 h-10 rounded mr-4 bg-neutral-500 flex-shrink-0`} />
                            )}
                            <div css={tw`flex-1 min-w-0`}>
                                <p css={tw`text-sm font-medium truncate`}>{hit.title}</p>
                                <p css={tw`text-xs text-neutral-400 truncate`}>{hit.description}</p>
                            </div>
                            <Button
                                size={'small'}
                                color={state === 'installed' ? 'green' : 'primary'}
                                onClick={() => setActiveHit(hit)}
                                css={tw`ml-4 flex-shrink-0`}
                            >
                                {state === 'installed' ? (
                                    <>
                                        <FontAwesomeIcon icon={faCheckCircle} css={tw`mr-2`} />
                                        Installed
                                    </>
                                ) : (
                                    <>
                                        <FontAwesomeIcon icon={faDownload} css={tw`mr-2`} />
                                        Install
                                    </>
                                )}
                            </Button>
                        </GreyRowBox>
                    );
                })
            )}
        </ServerContentBlock>
    );
};
