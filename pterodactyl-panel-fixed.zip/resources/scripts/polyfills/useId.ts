import React from 'react';

/**
 * This project runs React 16.14, but a handful of dependencies
 * (namely @floating-ui/react-dom-interactions, used by our Tooltip
 * component) call React 18's `useId()` hook unconditionally instead of
 * feature-detecting it first. On React 16 that hook does not exist,
 * which throws "TypeError: X.useId is not a function" as soon as any
 * component using those hooks (e.g. NavigationBar's tooltips) mounts.
 *
 * This polyfills `React.useId` with a functionally equivalent
 * implementation (a stable, unique id for the lifetime of the
 * component instance) so those dependencies work unmodified. This
 * must be imported before anything else that might trigger a render,
 * so it is the very first import in index.tsx.
 */
if (typeof (React as unknown as { useId?: unknown }).useId !== 'function') {
    let idCounter = 0;

    (React as unknown as { useId: () => string }).useId = function useId(): string {
        const ref = React.useRef<string | null>(null);
        if (ref.current === null) {
            idCounter += 1;
            ref.current = `:r${idCounter.toString(36)}:`;
        }

        return ref.current;
    };
}
