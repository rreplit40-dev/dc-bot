import React from 'react';
import styled from 'styled-components/macro';
import tw, { theme } from 'twin.macro';
import { breakpoint } from '@/theme';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
    faTerminal,
    faFolder,
    faDatabase,
    faCalendarAlt,
    faUsers,
    faArchive,
    faNetworkWired,
    faPlay,
    faPuzzlePiece,
    faLayerGroup,
    faSlidersH,
    faHistory,
    faExternalLinkAlt,
    IconDefinition,
} from '@fortawesome/free-solid-svg-icons';

// Maps a server route's path to the icon shown next to it in the sidebar.
// Falls back to faSlidersH for anything not explicitly listed here.
const ICONS: Record<string, IconDefinition> = {
    '/': faTerminal,
    '/files': faFolder,
    '/databases': faDatabase,
    '/schedules': faCalendarAlt,
    '/users': faUsers,
    '/backups': faArchive,
    '/network': faNetworkWired,
    '/startup': faPlay,
    '/plugins': faPuzzlePiece,
    '/software': faLayerGroup,
    '/settings': faSlidersH,
    '/activity': faHistory,
};

export const getServerNavIcon = (path: string): IconDefinition => ICONS[path] ?? faSlidersH;

export const ServerSideNavigation = styled.div`
    ${tw`w-full bg-neutral-700 shadow overflow-x-auto flex-shrink-0`};

    ${breakpoint('md')`
        ${tw`w-56 overflow-x-visible overflow-y-auto`};
        min-height: calc(100vh - 3.5rem);
    `};

    & > div {
        ${tw`flex items-center text-sm px-2`};

        ${breakpoint('md')`
            ${tw`flex-col items-stretch px-3 py-4`};
        `};

        & > a,
        & > div,
        & > a.external {
            ${tw`flex items-center py-3 px-4 text-neutral-300 no-underline whitespace-nowrap transition-all duration-150 rounded`};

            & svg {
                ${tw`mr-3 flex-shrink-0`};
                width: 0.9rem;
            }

            &:not(:first-of-type) {
                ${tw`ml-2`};

                ${breakpoint('md')`
                    ${tw`ml-0 mt-1`};
                `};
            }

            &:hover {
                ${tw`text-neutral-100 bg-neutral-600`};
            }

            &:active,
            &.active {
                ${tw`text-neutral-100 bg-neutral-600`};
                box-shadow: inset 2px 0 ${theme`colors.cyan.600`.toString()};

                ${breakpoint('md')`
                    box-shadow: inset 3px 0 ${theme`colors.cyan.600`.toString()};
                `};
            }
        }
    }
`;

export { faExternalLinkAlt };

export default ServerSideNavigation;
