<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>
<body style="margin:0; padding:0; width:100%; background-color:#F2F4F6;">
    <table width="100%" cellpadding="0" cellspacing="0">
        <tr>
            <td align="center" style="padding:25px 0;">
                <a href="{{ url('/') }}" style="font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif; font-size:16px; font-weight:bold; color:#2F3133; text-decoration:none;">
                    {{ config('app.name') }}
                </a>
            </td>
        </tr>
        <tr>
            <td align="center">
                <table width="570" cellpadding="0" cellspacing="0" style="background:#FFFFFF; border-top:1px solid #EDEFF2; border-bottom:1px solid #EDEFF2;">
                    <tr>
                        <td style="font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif; padding:35px;">
                            <h1 style="margin-top:0; color:#2F3133; font-size:19px; font-weight:bold; text-align:left;">
                                {{ $greeting }}
                            </h1>

                            @foreach ($introLines as $line)
                                <p style="margin-top:0; color:#74787E; font-size:16px; line-height:1.5em;">{{ $line }}</p>
                            @endforeach

                            <table width="100%" cellpadding="0" cellspacing="0" style="margin:30px 0;">
                                <tr>
                                    <td align="center">
                                        <div style="display:inline-block; padding:18px 32px; background-color:#F2F4F6; border:1px solid #EDEFF2; border-radius:6px;">
                                            <span style="font-family:'Courier New', Courier, monospace; font-size:34px; font-weight:bold; letter-spacing:8px; color:#2F3133;">
                                                {{ $code }}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                            </table>

                            @foreach ($outroLines as $line)
                                <p style="margin-top:0; color:#74787E; font-size:16px; line-height:1.5em;">{{ $line }}</p>
                            @endforeach

                            <p style="margin-top:0; color:#74787E; font-size:16px; line-height:1.5em;">
                                Regards,<br>{{ config('app.name') }}
                            </p>
                        </td>
                    </tr>
                </table>
                <table width="570" cellpadding="0" cellspacing="0">
                    <tr>
                        <td style="font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif; color:#AEAEAE; padding:35px; text-align:center; font-size:12px;">
                            &copy; {{ date('Y') }} {{ config('app.name') }}. All rights reserved.
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
