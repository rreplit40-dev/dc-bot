<?php

namespace Pterodactyl\Http\Controllers\Auth;

use Carbon\CarbonImmutable;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Facades\Activity;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Notification;
use Pterodactyl\Exceptions\DisplayException;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\RegistrationVerification;
use Pterodactyl\Notifications\RegisterVerificationCode;

class RegisterController extends Controller
{
    /**
     * How many minutes a registration verification code remains valid for.
     */
    private const CODE_LIFETIME_MINUTES = 10;

    /**
     * Step 1: validate the submitted registration form, generate a one-time
     * code, store the pending registration, and email the code to the user.
     * No user record is created at this point.
     *
     * @throws \Illuminate\Validation\ValidationException
     * @throws DisplayException
     */
    public function sendCode(Request $request): JsonResponse
    {
        if (!config('pterodactyl.auth.registration.enabled', true)) {
            throw new DisplayException('Account registration is currently disabled.');
        }

        $data = $request->validate([
            'name_first' => 'required|string|max:191',
            'name_last' => 'required|string|max:191',
            'username' => ['required', 'string', 'between:1,191', 'alpha_dash', 'unique:users,username'],
            'email' => ['required', 'string', 'email', 'max:191', 'unique:users,email'],
            'password' => 'required|string|min:8|confirmed',
        ]);

        // Clear out any previous pending registration for this email address so
        // that a user retrying the form doesn't end up with stale rows / codes.
        RegistrationVerification::query()->where('email', $data['email'])->delete();

        $code = (string) random_int(100000, 999999);
        $reference = Str::random(40);

        RegistrationVerification::query()->create([
            'reference' => $reference,
            'name_first' => $data['name_first'],
            'name_last' => $data['name_last'],
            'username' => $data['username'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
            'code' => Hash::make($code),
            'attempts' => 0,
            'ip_address' => $request->ip(),
            'expires_at' => CarbonImmutable::now()->addMinutes(self::CODE_LIFETIME_MINUTES),
        ]);

        Notification::route('mail', $data['email'])
            ->notify(new RegisterVerificationCode($code, $data['name_first']));

        return new JsonResponse([
            'data' => [
                'reference' => $reference,
                'email' => $data['email'],
            ],
        ]);
    }

    /**
     * Step 2: verify the code the user received by email and, if valid,
     * create the real user account.
     *
     * @throws DisplayException
     * @throws \Illuminate\Validation\ValidationException
     */
    public function verify(Request $request): JsonResponse
    {
        $data = $request->validate([
            'reference' => 'required|string',
            'code' => 'required|string',
        ]);

        /** @var RegistrationVerification|null $pending */
        $pending = RegistrationVerification::query()->where('reference', $data['reference'])->first();

        if (!$pending) {
            throw new DisplayException('This registration request could not be found, please start over.');
        }

        if ($pending->expires_at->isBefore(CarbonImmutable::now())) {
            $pending->delete();

            throw new DisplayException('Your verification code has expired, please start the registration process again.');
        }

        if ($pending->attempts >= 5) {
            $pending->delete();

            throw new DisplayException('Too many incorrect attempts, please start the registration process again.');
        }

        if (!Hash::check($data['code'], $pending->code)) {
            $pending->increment('attempts');

            throw new DisplayException('The verification code you provided is not valid.');
        }

        // Double check the username / email were not taken by someone else while
        // this code was pending (e.g. two people registering the same details).
        $exists = User::query()
            ->where('username', $pending->username)
            ->orWhere('email', $pending->email)
            ->exists();

        if ($exists) {
            $pending->delete();

            throw new DisplayException('An account with that username or email already exists.');
        }

        $user = DB::transaction(function () use ($pending) {
            $user = User::query()->create([
                'external_id' => null,
                'username' => $pending->username,
                'email' => $pending->email,
                'name_first' => $pending->name_first,
                'name_last' => $pending->name_last,
                'password' => $pending->password,
                'language' => 'en',
                'root_admin' => false,
            ]);

            $pending->delete();

            return $user;
        });

        Activity::event('auth:register')->withRequestMetadata()->subject($user)->log();

        return new JsonResponse([
            'data' => [
                'complete' => true,
            ],
        ]);
    }
}
