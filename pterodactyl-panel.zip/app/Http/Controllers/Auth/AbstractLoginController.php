<?php

namespace Pterodactyl\Http\Controllers\Auth;

use Carbon\CarbonImmutable;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Illuminate\Auth\AuthManager;
use Illuminate\Http\JsonResponse;
use Illuminate\Auth\Events\Failed;
use Illuminate\Container\Container;
use Pterodactyl\Models\UserKnownIp;
use Illuminate\Support\Facades\Event;
use Pterodactyl\Events\Auth\DirectLogin;
use Illuminate\Support\Facades\Notification;
use Pterodactyl\Exceptions\DisplayException;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\UserIpVerification;
use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Pterodactyl\Notifications\LoginIpVerificationCode;

abstract class AbstractLoginController extends Controller
{
    use AuthenticatesUsers;

    protected AuthManager $auth;

    /**
     * Lockout time for failed login requests.
     */
    protected int $lockoutTime;

    /**
     * After how many attempts should logins be throttled and locked.
     */
    protected int $maxLoginAttempts;

    /**
     * Where to redirect users after login / registration.
     */
    protected string $redirectTo = '/';

    /**
     * LoginController constructor.
     */
    public function __construct()
    {
        $this->lockoutTime = config('auth.lockout.time');
        $this->maxLoginAttempts = config('auth.lockout.attempts');
        $this->auth = Container::getInstance()->make(AuthManager::class);
    }

    /**
     * Get the failed login response instance.
     *
     * @return never-return
     *
     * @throws DisplayException
     */
    protected function sendFailedLoginResponse(Request $request, ?Authenticatable $user = null, ?string $message = null)
    {
        $this->incrementLoginAttempts($request);
        $this->fireFailedLoginEvent($user, [
            $this->getField($request->input('user')) => $request->input('user'),
        ]);

        if ($request->route()->named('auth.login-checkpoint')) {
            throw new DisplayException($message ?? trans('auth.two_factor.checkpoint_failed'));
        }

        throw new DisplayException(trans('auth.failed'));
    }

    /**
     * Send the response after the user was authenticated.
     */
    protected function sendLoginResponse(User $user, Request $request): JsonResponse
    {
        $request->session()->remove('auth_confirmation_token');
        $request->session()->regenerate();

        $this->clearLoginAttempts($request);
        $this->rememberIp($user, $request);

        $this->auth->guard()->login($user, true);

        Event::dispatch(new DirectLogin($user, true));

        return new JsonResponse([
            'data' => [
                'complete' => true,
                'intended' => $this->redirectPath(),
                'user' => $user->toVueObject(),
            ],
        ]);
    }

    /**
     * Determine if the user is logging in using an email or username.
     */
    protected function getField(?string $input = null): string
    {
        return ($input && str_contains($input, '@')) ? 'email' : 'username';
    }

    /**
     * Determine if the request is coming from an IP address that we have
     * already seen (and verified) for this user in the past.
     */
    protected function isKnownIp(User $user, Request $request): bool
    {
        return UserKnownIp::query()
            ->where('user_id', $user->id)
            ->where('ip_address', $request->ip())
            ->exists();
    }

    /**
     * Store the current request IP address as a "known" / trusted IP for the
     * given user so that future logins from it do not require verification.
     */
    protected function rememberIp(User $user, Request $request): void
    {
        UserKnownIp::query()->updateOrCreate(
            ['user_id' => $user->id, 'ip_address' => $request->ip()],
            ['user_agent' => substr((string) $request->userAgent(), 0, 255), 'last_used_at' => CarbonImmutable::now()],
        );
    }

    /**
     * Generate and email a one-time verification code for a login attempt
     * coming from an IP address that has not been seen before, and return
     * the JSON response that tells the frontend to prompt for that code.
     */
    protected function sendIpVerificationChallenge(User $user, Request $request): JsonResponse
    {
        UserIpVerification::query()->where('user_id', $user->id)->delete();

        $code = (string) random_int(100000, 999999);
        $token = Str::random(64);

        UserIpVerification::query()->create([
            'user_id' => $user->id,
            'token' => $token,
            'ip_address' => $request->ip(),
            'code' => \Illuminate\Support\Facades\Hash::make($code),
            'attempts' => 0,
            'expires_at' => CarbonImmutable::now()->addMinutes(10),
        ]);

        Notification::send($user, new LoginIpVerificationCode($user, $code, (string) $request->ip()));

        return new JsonResponse([
            'data' => [
                'complete' => false,
                'requires_ip_verification' => true,
                'confirmation_token' => $token,
            ],
        ]);
    }

    /**
     * Called once a login attempt has either come from a known IP address, or
     * the user has just successfully completed the IP verification challenge.
     * This continues on to the 2FA checkpoint if enabled, or logs the user in.
     */
    protected function continueLoginAfterIpCheck(User $user, Request $request): JsonResponse
    {
        if (!$user->use_totp) {
            return $this->sendLoginResponse($user, $request);
        }

        return $this->sendTotpChallenge($user, $request);
    }

    /**
     * Store the confirmation token used for the existing TOTP checkpoint flow
     * and return the response instructing the frontend to prompt for it.
     */
    protected function sendTotpChallenge(User $user, Request $request): JsonResponse
    {
        $request->session()->put('auth_confirmation_token', [
            'user_id' => $user->id,
            'token_value' => $token = Str::random(64),
            'expires_at' => CarbonImmutable::now()->addMinutes(5),
        ]);

        return new JsonResponse([
            'data' => [
                'complete' => false,
                'confirmation_token' => $token,
            ],
        ]);
    }

    /**
     * Fire a failed login event.
     */
    protected function fireFailedLoginEvent(?Authenticatable $user = null, array $credentials = [])
    {
        Event::dispatch(new Failed('auth', $user, $credentials));
    }
}
