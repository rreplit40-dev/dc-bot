<?php

namespace Pterodactyl\Http\Controllers\Auth;

use Carbon\CarbonImmutable;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Hash;
use Pterodactyl\Models\UserIpVerification;

class LoginIpCheckpointController extends AbstractLoginController
{
    private const TOKEN_EXPIRED_MESSAGE = 'This verification request has expired, please try logging in again.';

    /**
     * Handle submission of the one-time code that was emailed to the user
     * because they logged in from an IP address we had not seen before.
     *
     * @throws \Pterodactyl\Exceptions\DisplayException
     * @throws \Illuminate\Validation\ValidationException
     */
    public function __invoke(Request $request): JsonResponse
    {
        if ($this->hasTooManyLoginAttempts($request)) {
            $this->sendLockoutResponse($request);
        }

        $data = $request->validate([
            'confirmation_token' => 'required|string',
            'code' => 'required|string',
        ]);

        /** @var UserIpVerification|null $pending */
        $pending = UserIpVerification::query()->where('token', $data['confirmation_token'])->first();

        if (!$pending) {
            $this->sendFailedLoginResponse($request, null, self::TOKEN_EXPIRED_MESSAGE);
        }

        if ($pending->expires_at->isBefore(CarbonImmutable::now())) {
            $pending->delete();
            $this->sendFailedLoginResponse($request, null, self::TOKEN_EXPIRED_MESSAGE);
        }

        if ($pending->attempts >= 5) {
            $pending->delete();
            $this->sendFailedLoginResponse($request, null, self::TOKEN_EXPIRED_MESSAGE);
        }

        // The code must be validated against the same IP address the challenge
        // was originally issued for.
        if ($pending->ip_address !== $request->ip() || !Hash::check($data['code'], $pending->code)) {
            $pending->increment('attempts');

            $this->sendFailedLoginResponse($request, null, 'The verification code you provided is not valid.');
        }

        $user = $pending->user()->firstOrFail();
        $pending->delete();

        $this->rememberIp($user, $request);

        return $this->continueLoginAfterIpCheck($user, $request);
    }
}
