import http from '@/api/http';
import { LoginResponse } from '@/api/auth/login';

export default (token: string, code: string): Promise<LoginResponse> => {
    return new Promise((resolve, reject) => {
        http.post('/auth/login/ip-checkpoint', {
            confirmation_token: token,
            code,
        })
            .then((response) =>
                resolve({
                    complete: response.data.data.complete,
                    intended: response.data.data.intended || undefined,
                    confirmationToken: response.data.data.confirmation_token || undefined,
                })
            )
            .catch(reject);
    });
};
