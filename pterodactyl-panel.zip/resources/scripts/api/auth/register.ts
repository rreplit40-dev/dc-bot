import http from '@/api/http';

export interface RegisterData {
    nameFirst: string;
    nameLast: string;
    username: string;
    email: string;
    password: string;
    passwordConfirmation: string;
    recaptchaData?: string | null;
}

export interface RegisterSendCodeResponse {
    reference: string;
    email: string;
}

export const sendRegistrationCode = ({
    nameFirst,
    nameLast,
    username,
    email,
    password,
    passwordConfirmation,
    recaptchaData,
}: RegisterData): Promise<RegisterSendCodeResponse> => {
    return new Promise((resolve, reject) => {
        http.get('/sanctum/csrf-cookie')
            .then(() =>
                http.post('/auth/register', {
                    name_first: nameFirst,
                    name_last: nameLast,
                    username,
                    email,
                    password,
                    password_confirmation: passwordConfirmation,
                    'g-recaptcha-response': recaptchaData,
                })
            )
            .then((response) =>
                resolve({
                    reference: response.data.data.reference,
                    email: response.data.data.email,
                })
            )
            .catch(reject);
    });
};

export const verifyRegistrationCode = (reference: string, code: string): Promise<void> => {
    return new Promise((resolve, reject) => {
        http.post('/auth/register/verify', { reference, code })
            .then(() => resolve())
            .catch(reject);
    });
};
