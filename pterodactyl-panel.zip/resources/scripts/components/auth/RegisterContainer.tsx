import React, { useEffect, useRef, useState } from 'react';
import { Link, RouteComponentProps } from 'react-router-dom';
import { sendRegistrationCode } from '@/api/auth/register';
import LoginFormContainer from '@/components/auth/LoginFormContainer';
import { useStoreState } from 'easy-peasy';
import { Formik, FormikHelpers } from 'formik';
import { object, string, ref as yupRef } from 'yup';
import Field from '@/components/elements/Field';
import tw from 'twin.macro';
import Button from '@/components/elements/Button';
import Reaptcha from 'reaptcha';
import useFlash from '@/plugins/useFlash';

interface Values {
    nameFirst: string;
    nameLast: string;
    username: string;
    email: string;
    password: string;
    passwordConfirmation: string;
}

const RegisterContainer = ({ history }: RouteComponentProps) => {
    const ref = useRef<Reaptcha>(null);
    const [token, setToken] = useState('');

    const { clearFlashes, clearAndAddHttpError } = useFlash();
    const { enabled: recaptchaEnabled, siteKey } = useStoreState((state) => state.settings.data!.recaptcha);

    useEffect(() => {
        clearFlashes();
    }, []);

    const onSubmit = (values: Values, { setSubmitting }: FormikHelpers<Values>) => {
        clearFlashes();

        if (recaptchaEnabled && !token) {
            ref.current!.execute().catch((error) => {
                console.error(error);

                setSubmitting(false);
                clearAndAddHttpError({ error });
            });

            return;
        }

        sendRegistrationCode({ ...values, recaptchaData: token })
            .then((response) => {
                history.replace('/auth/register/verify', { reference: response.reference, email: response.email });
            })
            .catch((error) => {
                console.error(error);

                setToken('');
                if (ref.current) ref.current.reset();

                setSubmitting(false);
                clearAndAddHttpError({ error });
            });
    };

    return (
        <Formik
            onSubmit={onSubmit}
            initialValues={{
                nameFirst: '',
                nameLast: '',
                username: '',
                email: '',
                password: '',
                passwordConfirmation: '',
            }}
            validationSchema={object().shape({
                nameFirst: string().required('Please enter your first name.'),
                nameLast: string().required('Please enter your last name.'),
                username: string()
                    .required('Please choose a username.')
                    .matches(/^[\w-]{1,191}$/, 'Username may only contain letters, numbers, dashes and underscores.'),
                email: string().email('Please enter a valid email address.').required('Please enter your email address.'),
                password: string().min(8, 'Password must be at least 8 characters.').required('Please enter a password.'),
                passwordConfirmation: string()
                    .oneOf([yupRef('password'), null], 'Password confirmation does not match.')
                    .required('Please confirm your password.'),
            })}
        >
            {({ isSubmitting }) => (
                <LoginFormContainer title={'Create an Account'} css={tw`w-full flex`}>
                    <div css={tw`grid grid-cols-1 md:grid-cols-2 gap-4`}>
                        <Field light type={'text'} label={'First Name'} name={'nameFirst'} disabled={isSubmitting} />
                        <Field light type={'text'} label={'Last Name'} name={'nameLast'} disabled={isSubmitting} />
                    </div>
                    <div css={tw`mt-6`}>
                        <Field light type={'text'} label={'Username'} name={'username'} disabled={isSubmitting} />
                    </div>
                    <div css={tw`mt-6`}>
                        <Field light type={'email'} label={'Email'} name={'email'} disabled={isSubmitting} />
                    </div>
                    <div css={tw`grid grid-cols-1 md:grid-cols-2 gap-4 mt-6`}>
                        <Field
                            light
                            type={'password'}
                            label={'Password'}
                            name={'password'}
                            disabled={isSubmitting}
                        />
                        <Field
                            light
                            type={'password'}
                            label={'Confirm Password'}
                            name={'passwordConfirmation'}
                            disabled={isSubmitting}
                        />
                    </div>
                    <div css={tw`mt-6`}>
                        <Button type={'submit'} size={'xlarge'} isLoading={isSubmitting} disabled={isSubmitting}>
                            Create Account
                        </Button>
                    </div>
                    {recaptchaEnabled && (
                        <Reaptcha
                            ref={ref}
                            size={'invisible'}
                            sitekey={siteKey || '_invalid_key'}
                            onVerify={(response) => setToken(response)}
                            onExpire={() => setToken('')}
                        />
                    )}
                    <div css={tw`mt-6 text-center`}>
                        <Link
                            to={'/auth/login'}
                            css={tw`text-xs text-neutral-500 tracking-wide no-underline uppercase hover:text-neutral-600`}
                        >
                            Already have an account? Login
                        </Link>
                    </div>
                </LoginFormContainer>
            )}
        </Formik>
    );
};

export default RegisterContainer;
