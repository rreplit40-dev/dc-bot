import React from 'react';
import { Link, RouteComponentProps } from 'react-router-dom';
import loginIpCheckpoint from '@/api/auth/loginIpCheckpoint';
import LoginFormContainer from '@/components/auth/LoginFormContainer';
import { StaticContext } from 'react-router';
import { Formik, FormikHelpers } from 'formik';
import { object, string } from 'yup';
import useFlash from '@/plugins/useFlash';
import Field from '@/components/elements/Field';
import tw from 'twin.macro';
import Button from '@/components/elements/Button';

interface Values {
    code: string;
}

type OwnProps = RouteComponentProps<Record<string, string | undefined>, StaticContext, { token?: string }>;

const LoginIpCheckpointContainer = ({ history, location }: OwnProps) => {
    const { clearFlashes, clearAndAddHttpError } = useFlash();

    if (!location.state?.token) {
        history.replace('/auth/login');

        return null;
    }

    const onSubmit = (values: Values, { setSubmitting }: FormikHelpers<Values>) => {
        clearFlashes();

        loginIpCheckpoint(location.state?.token || '', values.code)
            .then((response) => {
                if (response.complete) {
                    // @ts-expect-error this is valid
                    window.location = response.intended || '/';
                    return;
                }

                // The account also has 2FA enabled, continue on to that checkpoint.
                history.replace('/auth/login/checkpoint', { token: response.confirmationToken });
            })
            .catch((error) => {
                console.error(error);

                setSubmitting(false);
                clearAndAddHttpError({ error });
            });
    };

    return (
        <Formik
            onSubmit={onSubmit}
            initialValues={{ code: '' }}
            validationSchema={object().shape({
                code: string().required('Please enter the verification code sent to your email.'),
            })}
        >
            {({ isSubmitting }) => (
                <LoginFormContainer title={'New Login Detected'} css={tw`w-full flex`}>
                    <p css={tw`text-neutral-400 text-sm text-center`}>
                        We do not recognize this device or location. We have sent a verification code to your email
                        address, please enter it below to continue.
                    </p>
                    <div css={tw`mt-6`}>
                        <Field
                            light
                            name={'code'}
                            title={'Verification Code'}
                            type={'text'}
                            autoComplete={'one-time-code'}
                            autoFocus
                            disabled={isSubmitting}
                        />
                    </div>
                    <div css={tw`mt-6`}>
                        <Button size={'xlarge'} type={'submit'} disabled={isSubmitting} isLoading={isSubmitting}>
                            Verify & Continue
                        </Button>
                    </div>
                    <div css={tw`mt-6 text-center`}>
                        <Link
                            to={'/auth/login'}
                            css={tw`text-xs text-neutral-500 tracking-wide uppercase no-underline hover:text-neutral-700`}
                        >
                            Return to Login
                        </Link>
                    </div>
                </LoginFormContainer>
            )}
        </Formik>
    );
};

export default LoginIpCheckpointContainer;
