import React from 'react';
import { Link, RouteComponentProps } from 'react-router-dom';
import { verifyRegistrationCode } from '@/api/auth/register';
import LoginFormContainer from '@/components/auth/LoginFormContainer';
import { StaticContext } from 'react-router';
import { Formik, FormikHelpers } from 'formik';
import { object, string } from 'yup';
import Field from '@/components/elements/Field';
import tw from 'twin.macro';
import Button from '@/components/elements/Button';
import useFlash from '@/plugins/useFlash';

interface Values {
    code: string;
}

type OwnProps = RouteComponentProps<
    Record<string, string | undefined>,
    StaticContext,
    { reference?: string; email?: string }
>;

const RegisterVerifyContainer = ({ history, location }: OwnProps) => {
    const { clearFlashes, addFlash, clearAndAddHttpError } = useFlash();

    if (!location.state?.reference) {
        history.replace('/auth/register');

        return null;
    }

    const onSubmit = (values: Values, { setSubmitting }: FormikHelpers<Values>) => {
        clearFlashes();

        verifyRegistrationCode(location.state?.reference || '', values.code)
            .then(() => {
                addFlash({
                    type: 'success',
                    title: 'Success',
                    message: 'Your account has been created, you may now login.',
                });

                history.replace('/auth/login');
            })
            .catch((error) => {
                console.error(error);

                setSubmitting(false);
                clearAndAddHttpError({ error });
            });
    };

    return (
        <Formik
            onSubmit={onSubmit}
            initialValues={{ code: '' }}
            validationSchema={object().shape({
                code: string().required('Please enter the verification code sent to your email.'),
            })}
        >
            {({ isSubmitting }) => (
                <LoginFormContainer title={'Verify Your Email'} css={tw`w-full flex`}>
                    <p css={tw`text-neutral-400 text-sm text-center`}>
                        We&apos;ve sent a verification code to <strong>{location.state?.email}</strong>. Enter it
                        below to finish creating your account. If you don&apos;t see it soon, check your spam or
                        junk folder.
                    </p>
                    <div css={tw`mt-6`}>
                        <Field
                            light
                            name={'code'}
                            label={'Verification Code'}
                            type={'text'}
                            autoComplete={'one-time-code'}
                            autoFocus
                            disabled={isSubmitting}
                        />
                    </div>
                    <div css={tw`mt-6`}>
                        <Button size={'xlarge'} type={'submit'} disabled={isSubmitting} isLoading={isSubmitting}>
                            Create Account
                        </Button>
                    </div>
                    <div css={tw`mt-6 text-center`}>
                        <Link
                            to={'/auth/register'}
                            css={tw`text-xs text-neutral-500 tracking-wide uppercase no-underline hover:text-neutral-700`}
                        >
                            Back
                        </Link>
                    </div>
                </LoginFormContainer>
            )}
        </Formik>
    );
};

export default RegisterVerifyContainer;
