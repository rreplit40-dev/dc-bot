import React, { useEffect, useState } from 'react';
import debounce from 'debounce';
import tw from 'twin.macro';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faDownload, faCheckCircle, faSearch } from '@fortawesome/free-solid-svg-icons';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import FlashMessageRender from '@/components/FlashMessageRender';
import Input from '@/components/elements/Input';
import Button from '@/components/elements/Button';
import GreyRowBox from '@/components/elements/GreyRowBox';
import Spinner from '@/components/elements/Spinner';
import useFlash from '@/plugins/useFlash';
import { ServerContext } from '@/state/server';
import pullFile from '@/api/server/files/pullFile';
import {
    ModrinthSearchHit,
    PLUGIN_LOADERS,
    PluginLoader,
    resolveLatestDownload,
    searchPlugins,
} from '@/api/server/plugins/modrinth';

const PLUGINS_DIRECTORY = '/plugins';

// Which loader we default to search under. Server admins running Paper are
// by far the most common case, so that's the sane default.
const DEFAULT_LOADER: PluginLoader = 'paper';

type InstallState = 'idle' | 'installing' | 'installed' | 'error';

export default () => {
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const { addError, clearFlashes } = useFlash();

    const [loader, setLoader] = useState<PluginLoader>(DEFAULT_LOADER);
    const [query, setQuery] = useState('');
    const [loading, setLoading] = useState(false);
    const [results, setResults] = useState<ModrinthSearchHit[]>([]);
    const [installState, setInstallState] = useState<Record<string, InstallState>>({});

    const runSearch = debounce((value: string, forLoader: PluginLoader) => {
        setLoading(true);
        clearFlashes('plugins');

        searchPlugins(value, forLoader)
            .then((response) => setResults(response.hits))
            .catch((error) => {
                console.error(error);
                addError({ key: 'plugins', message: 'Could not reach Modrinth — try again in a moment.' });
            })
            .then(() => setLoading(false));
    }, 350);

    useEffect(() => {
        runSearch(query, loader);
        return () => runSearch.clear();
    }, [query, loader]);

    const install = (hit: ModrinthSearchHit) => {
        setInstallState((prev) => ({ ...prev, [hit.project_id]: 'installing' }));
        clearFlashes('plugins');

        resolveLatestDownload(hit.project_id, loader)
            .then((file) => {
                if (!file) {
                    throw new Error(`No build of "${hit.title}" is available for ${loader}.`);
                }

                return pullFile(uuid, {
                    url: file.url,
                    directory: PLUGINS_DIRECTORY,
                    filename: file.filename,
                });
            })
            .then(() => setInstallState((prev) => ({ ...prev, [hit.project_id]: 'installed' })))
            .catch((error) => {
                console.error(error);
                setInstallState((prev) => ({ ...prev, [hit.project_id]: 'error' }));
                addError({ key: 'plugins', message: error?.message ?? 'Installation failed.' });
            });
    };

    return (
        <ServerContentBlock title={'Plugins'}>
            <FlashMessageRender byKey={'plugins'} css={tw`mb-4`} />

            <div css={tw`flex flex-col sm:flex-row gap-4 mb-4`}>
                <div css={tw`flex-1 relative`}>
                    <FontAwesomeIcon
                        icon={faSearch}
                        css={tw`absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400`}
                    />
                    <Input
                        css={tw`pl-9`}
                        placeholder={'Search plugins (e.g. EssentialsX, LuckPerms, Vault)'}
                        value={query}
                        onChange={(e) => setQuery(e.currentTarget.value)}
                    />
                </div>
                <select
                    css={tw`bg-neutral-600 border-2 border-neutral-500 rounded text-sm text-neutral-200 p-3`}
                    value={loader}
                    onChange={(e) => setLoader(e.currentTarget.value as PluginLoader)}
                >
                    {PLUGIN_LOADERS.map((l) => (
                        <option key={l} value={l}>
                            {l[0].toUpperCase() + l.slice(1)}
                        </option>
                    ))}
                </select>
            </div>

            <p css={tw`text-xs text-neutral-400 mb-4`}>
                Installing a plugin downloads its jar directly onto this server into{' '}
                <code css={tw`text-neutral-300`}>/plugins</code>. Restart the server for it to load.
            </p>

            {loading ? (
                <Spinner size={'large'} centered />
            ) : results.length === 0 ? (
                <p css={tw`text-center text-sm text-neutral-300`}>
                    {query ? 'No plugins found for that search.' : 'Start typing to search Modrinth for plugins.'}
                </p>
            ) : (
                results.map((hit, index) => {
                    const state = installState[hit.project_id] ?? 'idle';

                    return (
                        <GreyRowBox key={hit.project_id} css={index > 0 ? tw`mt-2` : undefined}>
                            {hit.icon_url ? (
                                <img src={hit.icon_url} css={tw`w-10 h-10 rounded mr-4`} alt={hit.title} />
                            ) : (
                                <div css={tw`w-10 h-10 rounded mr-4 bg-neutral-500 flex-shrink-0`} />
                            )}
                            <div css={tw`flex-1 min-w-0`}>
                                <p css={tw`text-sm font-medium truncate`}>{hit.title}</p>
                                <p css={tw`text-xs text-neutral-400 truncate`}>{hit.description}</p>
                            </div>
                            <Button
                                size={'small'}
                                color={state === 'installed' ? 'green' : 'primary'}
                                disabled={state === 'installing' || state === 'installed'}
                                onClick={() => install(hit)}
                                css={tw`ml-4 flex-shrink-0`}
                            >
                                {state === 'installing' ? (
                                    <Spinner size={'small'} />
                                ) : state === 'installed' ? (
                                    <>
                                        <FontAwesomeIcon icon={faCheckCircle} css={tw`mr-2`} />
                                        Installed
                                    </>
                                ) : (
                                    <>
                                        <FontAwesomeIcon icon={faDownload} css={tw`mr-2`} />
                                        Install
                                    </>
                                )}
                            </Button>
                        </GreyRowBox>
                    );
                })
            )}
        </ServerContentBlock>
    );
};
