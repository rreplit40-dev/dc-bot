import React, { useEffect, useState } from 'react';
import tw from 'twin.macro';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faDownload, faCheckCircle } from '@fortawesome/free-solid-svg-icons';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import FlashMessageRender from '@/components/FlashMessageRender';
import Button from '@/components/elements/Button';
import Spinner from '@/components/elements/Spinner';
import useFlash from '@/plugins/useFlash';
import { ServerContext } from '@/state/server';
import pullFile from '@/api/server/files/pullFile';
import { getGameVersions, getLatestBuildDownload, PaperProject } from '@/api/server/software/papermc';
import { getVanillaReleases, getVanillaServerDownload } from '@/api/server/software/vanilla';
import { getLatestBungeeCordBuild } from '@/api/server/software/bungeecord';

type Software = PaperProject | 'vanilla' | 'bungeecord';

const SOFTWARE_LABELS: Record<Software, string> = {
    paper: 'Paper',
    velocity: 'Velocity',
    waterfall: 'Waterfall',
    folia: 'Folia',
    vanilla: 'Vanilla',
    bungeecord: 'BungeeCord',
};

// BungeeCord doesn't have discrete "versions" the way Paper/Vanilla do — it's
// just a rolling build number — so there's no version dropdown for it.
const HAS_VERSION_LIST: Record<Software, boolean> = {
    paper: true,
    velocity: true,
    waterfall: true,
    folia: true,
    vanilla: true,
    bungeecord: false,
};

type InstallState = 'idle' | 'installing' | 'installed' | 'error';

export default () => {
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const { addError, clearFlashes } = useFlash();

    const [software, setSoftware] = useState<Software>('paper');
    const [versions, setVersions] = useState<string[]>([]);
    const [selectedVersion, setSelectedVersion] = useState('');
    const [loadingVersions, setLoadingVersions] = useState(false);
    const [installState, setInstallState] = useState<InstallState>('idle');

    useEffect(() => {
        setInstallState('idle');
        clearFlashes('software');

        if (!HAS_VERSION_LIST[software]) {
            setVersions([]);
            setSelectedVersion('');
            return;
        }

        setLoadingVersions(true);

        const loader = software === 'vanilla' ? getVanillaReleases() : getGameVersions(software as PaperProject);

        loader
            .then((list) => {
                setVersions(list);
                setSelectedVersion(list[0] ?? '');
            })
            .catch((error) => {
                console.error(error);
                addError({ key: 'software', message: error?.message ?? 'Failed to load versions.' });
            })
            .then(() => setLoadingVersions(false));
    }, [software]);

    const install = () => {
        setInstallState('installing');
        clearFlashes('software');

        const resolve =
            software === 'vanilla'
                ? getVanillaServerDownload(selectedVersion)
                : software === 'bungeecord'
                  ? getLatestBungeeCordBuild()
                  : getLatestBuildDownload(software as PaperProject, selectedVersion);

        resolve
            .then((file) =>
                pullFile(uuid, {
                    url: file.url,
                    directory: '/',
                    filename: 'server.jar',
                })
            )
            .then(() => setInstallState('installed'))
            .catch((error) => {
                console.error(error);
                setInstallState('error');
                addError({ key: 'software', message: error?.message ?? 'Installation failed.' });
            });
    };

    return (
        <ServerContentBlock title={'Software'}>
            <FlashMessageRender byKey={'software'} css={tw`mb-4`} />

            <p css={tw`text-sm text-neutral-300 mb-6`}>
                Switch your server between Paper, Velocity, Waterfall, Folia, Vanilla, or BungeeCord, and jump
                between versions. This downloads the jar directly onto the server as{' '}
                <code css={tw`text-neutral-200`}>server.jar</code> — make sure your Startup command points at that
                filename, then restart the server afterwards.
            </p>

            <div css={tw`grid grid-cols-2 sm:grid-cols-3 gap-2 mb-6`}>
                {(Object.keys(SOFTWARE_LABELS) as Software[]).map((key) => (
                    <button
                        key={key}
                        type={'button'}
                        onClick={() => setSoftware(key)}
                        css={[
                            tw`p-3 rounded border-2 text-sm text-left transition-colors`,
                            software === key
                                ? tw`border-primary-400 bg-primary-500 bg-opacity-10 text-primary-200`
                                : tw`border-neutral-600 bg-neutral-700 text-neutral-300 hover:border-neutral-500`,
                        ]}
                    >
                        {SOFTWARE_LABELS[key]}
                    </button>
                ))}
            </div>

            {HAS_VERSION_LIST[software] && (
                <div css={tw`mb-6`}>
                    <label css={tw`block text-xs uppercase text-neutral-400 mb-2`}>Version</label>
                    {loadingVersions ? (
                        <Spinner size={'small'} />
                    ) : (
                        <select
                            css={tw`w-full sm:w-64 bg-neutral-600 border-2 border-neutral-500 rounded text-sm text-neutral-200 p-3`}
                            value={selectedVersion}
                            onChange={(e) => setSelectedVersion(e.currentTarget.value)}
                        >
                            {versions.map((v) => (
                                <option key={v} value={v}>
                                    {v}
                                </option>
                            ))}
                        </select>
                    )}
                </div>
            )}

            {software === 'bungeecord' && (
                <p css={tw`text-xs text-neutral-400 mb-6`}>
                    BungeeCord ships as a rolling build rather than versioned releases — installing always grabs the
                    latest successful build.
                </p>
            )}

            <Button
                color={installState === 'installed' ? 'green' : 'primary'}
                disabled={
                    installState === 'installing' ||
                    (HAS_VERSION_LIST[software] && (!selectedVersion || loadingVersions))
                }
                onClick={install}
            >
                {installState === 'installing' ? (
                    <Spinner size={'small'} />
                ) : installState === 'installed' ? (
                    <>
                        <FontAwesomeIcon icon={faCheckCircle} css={tw`mr-2`} />
                        Installed — restart to apply
                    </>
                ) : (
                    <>
                        <FontAwesomeIcon icon={faDownload} css={tw`mr-2`} />
                        Install {SOFTWARE_LABELS[software]}
                    </>
                )}
            </Button>
        </ServerContentBlock>
    );
};
