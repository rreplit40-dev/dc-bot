import http from '@/api/http';

interface PullFileParams {
    url: string;
    directory: string;
    filename?: string;
    useHeader?: boolean;
    foreground?: boolean;
}

/**
 * Tells Wings (the node daemon) to download a file from a remote URL directly
 * onto the server's disk. This never touches the user's browser/bandwidth —
 * the daemon does the download itself. Used by the Plugin Installer and the
 * Software/Version changer.
 */
export default async (uuid: string, params: PullFileParams): Promise<void> => {
    await http.post(`/api/client/servers/${uuid}/files/pull`, {
        url: params.url,
        directory: params.directory,
        filename: params.filename,
        use_header: params.useHeader ?? false,
        foreground: params.foreground ?? false,
    });
};
