// Client for the public PaperMC API (https://docs.papermc.io/misc/downloads-api).
// Covers Paper, Velocity, Waterfall and Folia — they're all published under the
// same api.papermc.io/v2 endpoint, just with a different "project" name.

const PAPERMC_API = 'https://api.papermc.io/v2';

export type PaperProject = 'paper' | 'velocity' | 'waterfall' | 'folia';

interface ProjectVersionsResponse {
    versions: string[];
}

interface VersionBuildsResponse {
    builds: {
        build: number;
        channel: string;
        downloads: {
            application: {
                name: string;
            };
        };
    }[];
}

export async function getGameVersions(project: PaperProject): Promise<string[]> {
    const response = await fetch(`${PAPERMC_API}/projects/${project}`);
    if (!response.ok) {
        throw new Error(`Failed to load ${project} versions (status ${response.status})`);
    }

    const data: ProjectVersionsResponse = await response.json();
    // Newest first.
    return [...data.versions].reverse();
}

export async function getLatestBuildDownload(
    project: PaperProject,
    version: string
): Promise<{ url: string; filename: string; build: number }> {
    const response = await fetch(`${PAPERMC_API}/projects/${project}/versions/${version}/builds`);
    if (!response.ok) {
        throw new Error(`Failed to load builds for ${project} ${version} (status ${response.status})`);
    }

    const data: VersionBuildsResponse = await response.json();
    if (!data.builds.length) {
        throw new Error(`No builds published for ${project} ${version}.`);
    }

    const latest = data.builds[data.builds.length - 1];
    const filename = latest.downloads.application.name;

    return {
        url: `${PAPERMC_API}/projects/${project}/versions/${version}/builds/${latest.build}/downloads/${filename}`,
        filename,
        build: latest.build,
    };
}
