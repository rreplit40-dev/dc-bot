// Client for Mojang's public version manifest — used to install vanilla
// `server.jar` builds. No key required.

const MANIFEST_URL = 'https://piston-meta.mojang.com/mc/game/version_manifest_v2.json';

interface ManifestVersion {
    id: string;
    type: 'release' | 'snapshot' | 'old_beta' | 'old_alpha';
    url: string;
}

interface Manifest {
    versions: ManifestVersion[];
}

interface VersionMeta {
    downloads: {
        server?: {
            url: string;
        };
    };
}

let cachedManifest: Manifest | null = null;

async function getManifest(): Promise<Manifest> {
    if (cachedManifest) return cachedManifest;

    const response = await fetch(MANIFEST_URL);
    if (!response.ok) {
        throw new Error(`Failed to load Minecraft version manifest (status ${response.status})`);
    }

    cachedManifest = await response.json();
    return cachedManifest!;
}

export async function getVanillaReleases(): Promise<string[]> {
    const manifest = await getManifest();
    return manifest.versions.filter((v) => v.type === 'release').map((v) => v.id);
}

export async function getVanillaServerDownload(version: string): Promise<{ url: string; filename: string }> {
    const manifest = await getManifest();
    const entry = manifest.versions.find((v) => v.id === version);
    if (!entry) {
        throw new Error(`Unknown Minecraft version ${version}.`);
    }

    const versionResponse = await fetch(entry.url);
    if (!versionResponse.ok) {
        throw new Error(`Failed to load version metadata for ${version}.`);
    }

    const meta: VersionMeta = await versionResponse.json();
    if (!meta.downloads.server) {
        throw new Error(`Minecraft ${version} does not have a server jar (client-only version).`);
    }

    return { url: meta.downloads.server.url, filename: 'server.jar' };
}
