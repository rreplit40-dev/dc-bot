// BungeeCord has no versioned releases like Paper does — it ships as a rolling
// set of build numbers straight off SpigotMC's Jenkins. There's no dedicated
// download API, so we read the Jenkins job JSON directly.
//
// NOTE: unlike the PaperMC and Mojang APIs, Jenkins at ci.md-5.net is not
// guaranteed to send CORS headers for browser fetches. If this call fails
// with a network/CORS error, the fallback is to proxy it through the panel
// backend (a one-line controller that fetches this same URL server-side and
// returns it as JSON) — see the note in SoftwareContainer.tsx.

const JENKINS_JOB = 'https://ci.md-5.net/job/BungeeCord';

interface JenkinsBuild {
    number: number;
}

export async function getLatestBungeeCordBuild(): Promise<{ url: string; filename: string; build: number }> {
    const response = await fetch(`${JENKINS_JOB}/lastSuccessfulBuild/api/json?tree=number`);
    if (!response.ok) {
        throw new Error(`Failed to reach BungeeCord's build server (status ${response.status})`);
    }

    const build: JenkinsBuild = await response.json();

    return {
        url: `${JENKINS_JOB}/${build.number}/artifact/bootstrap/target/BungeeCord.jar`,
        filename: 'BungeeCord.jar',
        build: build.number,
    };
}
