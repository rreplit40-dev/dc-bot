// Lightweight client for the public Modrinth API (https://docs.modrinth.com/api/).
// No API key required — this is called directly from the browser.

export interface ModrinthSearchHit {
    project_id: string;
    slug: string;
    title: string;
    description: string;
    icon_url: string | null;
    downloads: number;
    categories: string[];
    latest_version: string;
}

export interface ModrinthSearchResponse {
    hits: ModrinthSearchHit[];
    total_hits: number;
}

export interface ModrinthVersionFile {
    url: string;
    filename: string;
    primary: boolean;
}

export interface ModrinthVersion {
    id: string;
    version_number: string;
    game_versions: string[];
    loaders: string[];
    files: ModrinthVersionFile[];
}

const MODRINTH_API = 'https://api.modrinth.com/v2';

// The server software types we support installing plugins for. Modrinth calls
// these "loaders" — matching against them is how we make sure a Paper server
// isn't shown a Fabric mod, etc.
export const PLUGIN_LOADERS = ['paper', 'spigot', 'purpur', 'bukkit', 'folia', 'velocity', 'waterfall', 'bungeecord'] as const;

export type PluginLoader = (typeof PLUGIN_LOADERS)[number];

export async function searchPlugins(query: string, loader: PluginLoader, offset = 0): Promise<ModrinthSearchResponse> {
    const facets = JSON.stringify([[`categories:${loader}`], ['project_type:plugin', 'project_type:mod']]);

    const params = new URLSearchParams({
        query,
        facets,
        limit: '20',
        offset: String(offset),
        index: 'relevance',
    });

    const response = await fetch(`${MODRINTH_API}/search?${params.toString()}`);
    if (!response.ok) {
        throw new Error(`Modrinth search failed with status ${response.status}`);
    }

    return response.json();
}

export async function getProjectVersions(projectId: string, loader: PluginLoader): Promise<ModrinthVersion[]> {
    const params = new URLSearchParams({ loaders: JSON.stringify([loader]) });

    const response = await fetch(`${MODRINTH_API}/project/${projectId}/version?${params.toString()}`);
    if (!response.ok) {
        throw new Error(`Failed to load versions for ${projectId} (status ${response.status})`);
    }

    return response.json();
}

/**
 * Resolves the primary downloadable jar for the newest version of a project
 * that supports the given loader. Returns null if nothing compatible exists.
 */
export async function resolveLatestDownload(
    projectId: string,
    loader: PluginLoader
): Promise<{ url: string; filename: string; versionNumber: string } | null> {
    const versions = await getProjectVersions(projectId, loader);
    if (!versions.length) return null;

    const [latest] = versions;
    const file = latest.files.find((f) => f.primary) ?? latest.files[0];
    if (!file) return null;

    return { url: file.url, filename: file.filename, versionNumber: latest.version_number };
}
