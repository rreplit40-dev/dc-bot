This zip has only the 7 brand-new files. Copy this `resources/` folder
into your panel install, merging it in (don't overwrite the whole
resources folder — just let these new subfolders/files drop in
alongside your existing ones).

ONE FILE IS NOT NEW and can't be included as a plain copy, because it's
an edit to a file you already have: resources/scripts/routers/routes.ts

Open that file yourself and make these two changes:

1. Near the top, next to the other server component imports, add:

import PluginsContainer from '@/components/server/plugins/PluginsContainer';
import SoftwareContainer from '@/components/server/software/SoftwareContainer';

2. Inside the `server` route list, right after the `/startup` route
   object, add these two route objects:

        {
            path: '/plugins',
            permission: 'file.create',
            name: 'Plugins',
            component: PluginsContainer,
        },
        {
            path: '/software',
            permission: 'file.create',
            name: 'Software',
            component: SoftwareContainer,
        },

After that: yarn install (if needed) -> yarn run build:production ->
php artisan view:clear -> php artisan cache:clear -> hard refresh
the browser.
