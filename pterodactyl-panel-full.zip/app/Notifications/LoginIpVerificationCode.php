<?php

namespace Pterodactyl\Notifications;

use Pterodactyl\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;

class LoginIpVerificationCode extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(public User $user, public string $code, public string $ipAddress)
    {
    }

    public function via(): array
    {
        return ['mail'];
    }

    public function toMail(): MailMessage
    {
        return (new MailMessage())
            ->subject('New login detected on ' . config('app.name'))
            ->greeting('Hello ' . ($this->user->name_first ?: $this->user->username) . ',')
            ->line('We noticed a login attempt to your account from a device or location we do not recognize.')
            ->line('IP Address: ' . $this->ipAddress)
            ->line('')
            ->line('**Your verification code is: ' . $this->code . '**')
            ->line('')
            ->line('Enter this code to complete your login. This code will expire in 10 minutes.')
            ->line('If this was not you, we recommend changing your password immediately.')
            ->salutation('Regards, ' . config('app.name'));
    }
}
