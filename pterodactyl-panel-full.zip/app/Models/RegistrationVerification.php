<?php

namespace Pterodactyl\Models;

/**
 * Pterodactyl\Models\RegistrationVerification.
 *
 * @property int $id
 * @property string $reference
 * @property string $name_first
 * @property string $name_last
 * @property string $username
 * @property string $email
 * @property string $password
 * @property string $code
 * @property int $attempts
 * @property string|null $ip_address
 * @property \Carbon\CarbonImmutable $expires_at
 */
class RegistrationVerification extends Model
{
    public $timestamps = true;

    protected $table = 'registration_verifications';

    protected $fillable = [
        'reference',
        'name_first',
        'name_last',
        'username',
        'email',
        'password',
        'code',
        'attempts',
        'ip_address',
        'expires_at',
    ];

    protected $casts = [
        'expires_at' => 'immutable_datetime',
        'attempts' => 'integer',
    ];

    protected $hidden = [
        'password',
        'code',
    ];
}
