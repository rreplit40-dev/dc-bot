<?php

namespace Pterodactyl\Models;

/**
 * Pterodactyl\Models\UserIpVerification.
 *
 * @property int $id
 * @property int $user_id
 * @property string $token
 * @property string $ip_address
 * @property string $code
 * @property int $attempts
 * @property \Carbon\CarbonImmutable $expires_at
 */
class UserIpVerification extends Model
{
    public $timestamps = true;

    protected $table = 'user_ip_verifications';

    protected $fillable = [
        'user_id',
        'token',
        'ip_address',
        'code',
        'attempts',
        'expires_at',
    ];

    protected $casts = [
        'expires_at' => 'immutable_datetime',
        'attempts' => 'integer',
    ];

    protected $hidden = [
        'code',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
