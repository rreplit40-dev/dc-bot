<?php

namespace Pterodactyl\Models;

/**
 * Pterodactyl\Models\UserKnownIp.
 *
 * @property int $id
 * @property int $user_id
 * @property string $ip_address
 * @property string|null $user_agent
 * @property \Carbon\CarbonImmutable|null $last_used_at
 */
class UserKnownIp extends Model
{
    public $timestamps = true;

    protected $table = 'user_known_ips';

    protected $fillable = [
        'user_id',
        'ip_address',
        'user_agent',
        'last_used_at',
    ];

    protected $casts = [
        'last_used_at' => 'immutable_datetime',
    ];
}
